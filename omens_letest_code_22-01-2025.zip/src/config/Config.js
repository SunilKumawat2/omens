const API_BASE_URL = "https://rasatva.apponedemo.top/omens/api";  
const IMG_BASE_URL = "https://rasatva.apponedemo.top/omens/";  
const THIRD_PARTY_API_BASE_URL = "https://json.astrologyapi.com/v1";  
const THIRD_PARTY_API_KEY = "862d14e22a9102bf8130c3d3be13160b671aabf2";  
const THIRD_PARTY_USER_ID = "636721";  
const AGORA_APP_ID = "a0d5f8d66e014624ad5d695deb8fb69c";  

export {API_BASE_URL,IMG_BASE_URL,THIRD_PARTY_API_BASE_URL,THIRD_PARTY_USER_ID,THIRD_PARTY_API_KEY,AGORA_APP_ID}