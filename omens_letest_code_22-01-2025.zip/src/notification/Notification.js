import React, { useEffect } from "react";
import { requestPermission } from "../firebase/Firebase";

const Notification = () => {
  useEffect(() => {
    // Request permission on component mount
    requestPermission();
  }, []);

  return (
    <div>
      <h1>Notifications will appear here</h1>
    </div>
  );
};

export default Notification;
