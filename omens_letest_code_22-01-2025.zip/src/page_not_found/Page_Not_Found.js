import React from 'react'

const Page_Not_Found = () => {
  return (
    <div>Page_Not_Found</div>
  )
}

export default Page_Not_Found