import React, { useEffect, useState } from "react";
import { AgoraRTCProvider } from "agora-rtc-react";
import { AgoraRTC } from "agora-rtc-sdk-ng";  // Correct import

const AGORA_APP_ID = "a0d5f8d66e014624ad5d695deb8fb69c"; // Your Agora App ID
const AGORA_CHANNEL = "OMNS2025-01-20 11:28:38"; // Provided channel name
const SENDER_ID = "5"; // Provided sender_id
const SENDER_TOKEN = "007eJxSYIjtUNsk7b84+Yfn+j/ZinbFn7vrwho2XuKZ9iZogq+P8h4FhkSDFNM0ixQzs1QDQxMzI5PEFNMUM0vTlNQki7QkM8vkNOO+9IZARobQlStYGBkgEMQXZ/D39Qs2MjAy1TUw1DUyUDA0tDKysDK2YGQwBQQAAP//7P4jHA=="; // Provided sender_token

const Agora_Voice_Call = ({ client }) => {
  const [localAudioTrack, setLocalAudioTrack] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleCallClick = async () => {
    if (!client) {
      console.error("Agora client is not initialized");
      return;
    }

    setIsLoading(true);
    try {
      // Join the Agora channel with the provided credentials
      await client.join(AGORA_APP_ID, AGORA_CHANNEL, SENDER_TOKEN, SENDER_ID);
      console.log("Joined channel:", AGORA_CHANNEL);

      // Create and publish the local audio track
      const audioTrack = await AgoraRTC.createMicrophoneAudioTrack();
      setLocalAudioTrack(audioTrack);
      await client.publish(audioTrack);
      console.log("Published local audio track");
    } catch (error) {
      console.error("Error joining channel or publishing audio:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    return () => {
      if (client) {
        client.leave().then(() => {
          console.log("Left the channel");
        }).catch((error) => {
          console.error("Error leaving the channel:", error);
        });

        // Stop and close the audio track
        if (localAudioTrack) {
          localAudioTrack.stop();
          localAudioTrack.close();
        }
      }
    };
  }, [client, localAudioTrack]);

  return (
    <div>
      <button onClick={handleCallClick} disabled={isLoading} className="call-button">
        {isLoading ? "Joining..." : "Start Call"}
      </button>
    </div>
  );
};

const Voice_Call = () => {
  const [client, setClient] = useState(null);

  useEffect(() => {
    // Initialize the Agora RTC client
    const rtcClient = AgoraRTC.createClient({ mode: "rtc", codec: "vp8" });

    if (rtcClient) {
      console.log("Agora RTC Client initialized:", rtcClient);
      setClient(rtcClient); // Set the initialized client to state
    } else {
      console.error("Failed to initialize Agora RTC Client.");
    }
  }, []);

  if (!client) {
    return <div>Loading...</div>; // Show loading state while Agora RTC client is initializing
  }

  return (
    <AgoraRTCProvider value={client}>
      <Agora_Voice_Call client={client} />
    </AgoraRTCProvider>
  );
};

export default Voice_Call;
