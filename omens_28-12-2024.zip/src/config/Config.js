const API_BASE_URL = "https://rasatva.apponedemo.top/omens/api";  
const IMG_BASE_URL = "https://rasatva.apponedemo.top/omens/";  

export {API_BASE_URL,IMG_BASE_URL}