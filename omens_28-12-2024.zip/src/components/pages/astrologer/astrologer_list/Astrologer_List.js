import React, { useEffect, useState } from 'react'
import Header from "../../../common/header/Header"
import Kundli_Main_Banner from '../../kundli/kundli_main_bannner/Kundli_Main_Banner'
import Astrologer_Sidebar from './Astrologer_Sidebar'
import Home_Private_Confidential from '../../home_page_components/home_private_confidential/Home_Private_Confidential'
import Footer from '../../../common/footer/Footer'
import { User_Authentication } from '../../../../user_authentication/User_Authentication'
import { Get_Astrologer_List } from '../../../../api/astrologer/Astrologer'
import Loader from '../../../../loader/Loader'
import { IMG_BASE_URL } from '../../../../config/Config'
import Common_Images_Transport from '../../../common/common_imges_transport/Common_Images_Transport'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer } from "react-toastify";

const Astrologer_List = () => {
    const token = User_Authentication()
    const navigate = useNavigate();
    const [is_loading, set_Is_Loading] = useState(false);
    const [astro_list, set_Astro_List] = useState([]);
    console.log("astro_list", astro_list)

    const [currentPage, setCurrentPage] = useState(1);
    const productsPerPage = 12; // Show 12 products per page

    // Calculate total pages safely
    const totalPages = Math.ceil(astro_list?.length / productsPerPage) || 1;

    // Calculate the products to display on the current page
    const startIndex = (currentPage - 1) * productsPerPage;
    const currentProduct = astro_list?.slice(startIndex, startIndex + productsPerPage) || [];

    // Pagination controls
    const handlePageChange = (page) => {
        setCurrentPage(page);
    };

    const handleNext = () => {
        if (currentPage < totalPages) {
            setCurrentPage(currentPage + 1);
        }
    };

    const handlePrev = () => {
        if (currentPage > 1) {
            setCurrentPage(currentPage - 1);
        }
    };

    useEffect(() => {
        const Handle_Get_astro_list = async () => {
            set_Is_Loading(true)
            try {
                const response = await Get_Astrologer_List("1")
                if (response?.data?.status == "200") {
                    set_Astro_List(response?.data?.data?.astrolist)
                    set_Is_Loading(false)
                }
                else if (response?.response?.data?.status == "500") {
                    set_Is_Loading(false)
                }
            } catch (error) {
                set_Is_Loading(false)
            }
        }
        Handle_Get_astro_list()
    }, [])

    // Scroll to the top of the page when the component is rendered
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);
    return (
        <div>
            {/* <-------- Header section's ----------> */}
            <Header />
            {/*  */}
            <Kundli_Main_Banner />
            {/* <-------- ToastContainer ------------> */}
            <ToastContainer style={{ marginTop: "120px" }} />
            {
                is_loading ? (
                    <Loader />
                ) : (
                    <>
                        <section className="gi-category py-[40px] max-[767px]:py-[30px] bg-[#F0F4F8]">
                            <div
                                className="flex flex-wrap justify-between items-center mx-auto min-[1400px]:max-w-[1320px] min-[1200px]:max-w-[1140px] min-[992px]:max-w-[960px] min-[768px]:max-w-[720px] min-[576px]:max-w-[540px]">
                                <div className="flex flex-wrap w-full">
                                    <div
                                        className="gi-shop-rightside min-[992px]:order-[6] min-[768px]:order-[-1] min-[992px]:w-[75%] min-[768px]:w-full w-full px-[12px]">
                                        {/* <!-- Shop Top Start --> */}
                                        <div className="gi-pro-list-top flex items-center justify-between text-[14px] mb-[15px]">
                                            <div className="min-[768px]:w-[50%] w-full gi-grid-list">
                                                <h2
                                                    className="text-[#4b5966] block text-[22px] leading-[33px] font-semibold mb-[10px] mx-auto leading-[0] capitalize">
                                                    All Astrologer List</h2>
                                            </div>
                                            {/* <div className="min-[768px]:w-[50%] w-full gi-sort-select flex justify-end items-center">
                                                <div className="gi-select-inner relative flex h-[50px] leading-[1.5] bg-[#fff] overflow-hidden">
                                                    <select name="gi-select" id="gi-select"
                                                        className=" outline-[0] bg-[#fff] grow-[1] text-[#777] cursor-pointer">
                                                        <option selected="" disabled="">Sort by</option>
                                                        <option value="1">Position</option>
                                                        <option value="2">Relevance</option>
                                                        <option value="3">Name, A to Z</option>
                                                        <option value="4">Name, Z to A</option>
                                                        <option value="5">Price, low to high</option>
                                                        <option value="6">Price, high to low</option>
                                                    </select>
                                                </div>
                                            </div> */}
                                        </div>
                                        {/* <!-- Shop Top End --> */}

                                        {/* <!-- Shop content Start --> */}
                                        <div className="shop-pro-content">
                                            <div className="shop-pro-inner mx-[-12px]">
                                                <div className="flex flex-wrap w-full">
                                                    {
                                                        currentProduct?.map((astro_list_result) => {
                                                            return (
                                                                <Link to={`/astrologer_details/${astro_list_result?.id}`} className="min-[992px]:w-[33.33%] min-[768px]:w-[50%] min-[576px]:w-[50%] max-[420px]:w-full px-[12px] max-[575px]:w-[50%] max-[575px]:mx-auto mb-6 grid_call_chat">
                                                                    <div className="gi-product-content bg-white" >
                                                                        <div
                                                                            className="gi-product-inner transition-all duration-[0.3s] ease-in-out overflow-hidden rounded-[5px] shadow-xl">
                                                                            <div
                                                                                className="gi-pro-image-outer transition-all duration-[0.3s] delay-[0s] ease z-[11] relative">
                                                                                <div className="astro_bg">
                                                                                    <div className="flex justify-between items-center">
                                                                                        <a href="javascript:void(0)"
                                                                                            className="mx-[5px] text-center grid  grid-flow-row auto-rows-max gap-2 items-center justify-center text-[15px]">
                                                                                            Call
                                                                                            <img src={Common_Images_Transport?.call_icon} className="m-auto"
                                                                                                alt="" />
                                                                                        </a>
                                                                                        <h6
                                                                                            className="gi-pro-stitle text-center font-normal text-[#000] text-[14px] font-semibold leading-[1.2] mt-4 capitalize">
                                                                                            Rs.{astro_list_result?.minute_rate}/min</h6>
                                                                                        <a href="javascript:void(0)"
                                                                                            className="mx-[5px] text-center grid  grid-flow-row auto-rows-max gap-2 items-center justify-center text-[15px]">
                                                                                            Chat
                                                                                            <img src={Common_Images_Transport?.chat_icon} className="m-auto"
                                                                                                alt="" />
                                                                                        </a>
                                                                                    </div>
                                                                                </div>
                                                                                <div className="gi-pro-image overflow-hidden">

                                                                                    <a href="#"
                                                                                        className="image productimg relative block overflow-hidden pointer-events-none">
                                                                                        {
                                                                                            astro_list_result?.profile_image != null ? (
                                                                                                <img className="main-image rounded-full m-auto  w-[120px] h-[120px] transition-all duration-[0.3s] ease delay-[0s]"
                                                                                                    src={`${IMG_BASE_URL}${astro_list_result?.profile_image}`} alt="astrologer" />

                                                                                            ) : (

                                                                                                <img className="main-image rounded-full m-auto  w-[120px] h-[120px] transition-all duration-[0.3s] ease delay-[0s]"
                                                                                                    src={Common_Images_Transport?.user_logo} alt="astrologer" />
                                                                                            )
                                                                                        }
                                                                                    </a>

                                                                                </div>
                                                                            </div>
                                                                            <div className="gi-pro-content h-full p-3 pb-5 relative z-[10]  text-center">
                                                                                <div
                                                                                    className="gi-pro-rat-price pb-2 flex d-flex justify-center gap-2 items-center">
                                                                                    <span className="gi-pro-rating opacity-[0.7] relative">
                                                                                        <i
                                                                                            className="gicon gi-star fill text-[16px] text-[#f27d0c] mr-[3px] float-left mr-[3px]"></i>
                                                                                        <i
                                                                                            className="gicon gi-star fill text-[16px] text-[#f27d0c] mr-[3px] float-left mr-[3px]"></i>
                                                                                        <i
                                                                                            className="gicon gi-star fill text-[16px] text-[#f27d0c] mr-[3px] float-left mr-[3px]"></i>
                                                                                        <i
                                                                                            className="gicon gi-star text-[16px] text-[#777] mr-[3px] float-left mr-[3px]"></i>
                                                                                        <i
                                                                                            className="gicon gi-star text-[16px] text-[#777] mr-[3px] float-left mr-[3px]"></i>
                                                                                    </span>
                                                                                    <span>4.5</span>
                                                                                </div>
                                                                                <a href="#">
                                                                                    <h5
                                                                                        className="gi-pro-stitle font-normal text-[#3B4959] text-[18px] font-semibold leading-[1.2] capitalize">{astro_list_result?.name}</h5>
                                                                                </a>
                                                                                <div className="mt-2">
                                                                                    <div className="skills-container">
                                                                                        {astro_list_result?.skills && (
                                                                                            <span
                                                                                                className="whitespace-nowrap inline-block text-gray-900 hover:text-white border border-gray-300 hover:bg-gray-900 rounded-full text-sm px-3 py-1 text-center mt-2"
                                                                                            >
                                                                                                {astro_list_result.skills.split(',')[0].trim()}
                                                                                            </span>
                                                                                        )}
                                                                                        {astro_list_result?.skills?.split(',').length > 1 && (
                                                                                            <span className="inline-block text-gray-500 text-sm ml-2">...</span>
                                                                                        )}
                                                                                    </div>

                                                                                    <div className="language-container">
                                                                                        {astro_list_result?.language && (
                                                                                            <span
                                                                                                className="whitespace-nowrap inline-block text-gray-900 hover:text-white border border-gray-300 hover:bg-gray-900 rounded-full text-sm px-3 py-1 text-center mt-2"
                                                                                            >
                                                                                                {astro_list_result.language.split(',')[0].trim()}
                                                                                            </span>
                                                                                        )}
                                                                                        {astro_list_result?.language?.split(',').length > 1 && (
                                                                                            <span className="inline-block text-gray-500 text-sm ml-2">...</span>
                                                                                        )}
                                                                                    </div>
                                                                                    <span
                                                                                        className="whitespace-nowrap inline-block text-gray-900 hover:text-white border border-gray-300 hover:bg-gray-900 rounded-full text-sm px-3 py-1 text-center mt-2">
                                                                                        {astro_list_result?.experience}</span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </Link>
                                                            )
                                                        })
                                                    }
                                                </div>
                                            </div>
                                            {/* <!-- Pagination Start --> */}
                                            <div className="gi-pro-pagination pt-[15px] pb-[15px] flex justify-between items-center border-t-[1px] border-solid border-[#eee] max-[575px]:flex-col">
                                                <span className="text-[14px] text-[#777] max-[575px]:mb-[10px]">Showing {startIndex + 1}-{Math.min(startIndex + productsPerPage, astro_list?.length)} of {astro_list?.length} item(s)</span>
                                                <ul className="gi-pro-pagination-inner flex">
                                                    <li>
                                                        <button onClick={handlePrev} className="next w-auto px-[13px] text-[#fff] m-1 p-2 bg-[#e17d7d] leading-[30px] h-[32px] bg-red-500 flex text-center align-top text-[16px] justify-center items-center rounded-[5px]">
                                                            Prev
                                                        </button>
                                                    </li>

                                                    {[...Array(totalPages).keys()].map((page) => (
                                                        <li key={page} className="inline-block float-left mr-[5px]">
                                                            <button
                                                                onClick={() => handlePageChange(page + 1)}
                                                                className={`transition-all duration-[0.3s] m-1 p-2 ease-in-out w-[32px] h-[32px] font-light 
                                                                        text-[#777] leading-[32px] bg-[#e17d7d] flex text-center align-top 
                                                                        text-[16px] justify-center items-center rounded-[5px]
                                                                         ${currentPage === page + 1 ? 'active bg-red-500 text-white' : 'bg-gray-300 text-white'}`}
                                                            >
                                                                {page + 1}
                                                            </button>
                                                        </li>
                                                    ))}

                                                    <li>
                                                        <button onClick={handleNext} className="next w-auto px-[13px] text-[#fff] m-1 p-2 bg-[#e17d7d] leading-[30px] h-[32px] bg-red-500 flex text-center align-top text-[16px] justify-center items-center rounded-[5px]">
                                                            Next
                                                        </button>
                                                    </li>
                                                </ul>
                                            </div>
                                            {/* <!-- Pagination End --> */}
                                        </div>
                                        {/* <!--Shop content End --> */}
                                    </div>
                                    {/* <!-- Sidebar Area Start --> */}
                                    <div
                                        className="gi-shop-sidebar sticky top-[24px] min-[992px]:order-[-1] min-[768px]:order-[6] min-[992px]:w-[25%] min-[768px]:w-full w-full max-[991px]:mt-[30px] px-[12px]">
                                        <div id="shop_sidebar">
                                            <div className="gi-sidebar-wrap p-[15px] bg-white rounded-[5px] shadow-lg">
                                                {/* <!-- Sidebar Category Block --> */}
                                                <Astrologer_Sidebar />
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </section>
                        {/* <--------- Home_Private_Confidential --------> */}
                        <Home_Private_Confidential />
                        {/* <-------- Footer section's -------> */}
                        <Footer />
                    </>
                )
            }

        </div>
    )
}

export default Astrologer_List