import React,{useState} from 'react'

const Kundli_Faq = () => {
    // State to track the active accordion
    const [activeIndex, setActiveIndex] = useState(0);

    // Function to handle accordion toggle
    const toggleAccordion = (index) => {
        setActiveIndex(index === activeIndex ? null : index);
    };

    return (
        <div>
            {/* <!-- Faq section --> */}
            <section className="gi-faq py-[40px] max-[767px]:py-[30px]">
                <div className="flex flex-wrap justify-between items-center mx-auto min-[1400px]:max-w-[1320px] min-[1200px]:max-w-[1140px] min-[992px]:max-w-[960px] min-[768px]:max-w-[720px] min-[576px]:max-w-[540px]">
                    <div className="section-title-2 w-full mb-[20px] pb-[20px] flex flex-col justify-center text-center px-[12px] items-center">
                        <h2 className="gi-title mb-[0] font-manrope text-[26px] font-semibold text-[#4b5966] relative inline p-[0] capitalize leading-[1]">
                            Frequently Asked Questions
                        </h2>
                    </div>
                    <div className="w-full flex flex-wrap">
                        <div className="min-[992px]:w-[80%] m-auto w-full px-[12px] max-[991px]:mt-[30px]">
                            <div className="gi-accordion style-1">
                                {[
                                    {
                                        question: "1. What is Janam Kundli?",
                                        answer:
                                            "Janam Kundli is a detailed birth chart that represents the positions of planets at the time of an individual's birth. It is widely used in Vedic astrology to make predictions about an individual's life.",
                                    },
                                    {
                                        question: "2. Can astrology predict the future accurately?",
                                        answer:
                                            "Astrology can provide insights based on planetary positions and patterns, but predicting the future with complete accuracy is subjective and depends on various factors.",
                                    },
                                    {
                                        question: "3. Which is the most accurate Kundli software?",
                                        answer:
                                            "Several Kundli software options are accurate, such as AstroSage and Kundli Chakra, which offer detailed astrological calculations.",
                                    },
                                    {
                                        question: "4. What is Navamsa chart?",
                                        answer:
                                            "The Navamsa chart is a divisional chart in Vedic astrology that provides deeper insights into a person's life, particularly in marriage, spirituality, and long-term goals.",
                                    },
                                    {
                                        question: "5. What is Lagna chart?",
                                        answer:
                                            "The Lagna chart, also known as the Ascendant chart, represents the planetary positions at the time of birth and is the primary chart used in Vedic astrology.",
                                    },
                                ].map((item, index) => (
                                    <div
                                        key={index}
                                        className="gi-accordion-item border-[#eee] overflow-hidden mb-[10px]"
                                    >
                                        <h4
                                            onClick={() => toggleAccordion(index)}
                                            className={`gi-accordion-header m-[0] py-[15px] pl-[20px] pr-[35px] bg-[#F0F4F8] text-[#4b5966] text-[16px] leading-[28px] cursor-pointer font-medium relative tracking-[0.01rem] max-[767px]:text-[15px] ${activeIndex === index ? "bg-[#dbe7f0]" : ""
                                                }`}
                                        >
                                            {item.question}
                                        </h4>
                                        <div
                                            className={`gi-accordion-body px-[20px] pb-[20px] text-[14px] text-[#7B8794] leading-[24px] bg-[#F0F4F8] ${activeIndex === index ? "block" : "hidden"
                                                }`}
                                        >
                                            {item.answer}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            {/* <!-- Faq section End --> */}
        </div>
    )
}

export default Kundli_Faq