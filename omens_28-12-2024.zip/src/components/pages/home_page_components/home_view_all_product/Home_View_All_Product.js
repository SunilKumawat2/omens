import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { Add_To_Fav, Get_Product_List, Product_List_Data } from '../../../../api/category_product/Category_Product'
import { IMG_BASE_URL } from '../../../../config/Config'
import Loader from '../../../../loader/Loader'
import Category_Main_Banner from '../../category/category_main_banner/Category_Main_Banner'
import Product_Filter from '../../product/Product_Filter'
import Footer from '../../../common/footer/Footer'
import Header from '../../../common/header/Header'
import { User_Authentication } from '../../../../user_authentication/User_Authentication'
import { toast } from 'react-toastify'
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer } from "react-toastify";
import Common_Images_Transport from '../../../common/common_imges_transport/Common_Images_Transport'

const Home_View_All_Product = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const { gemstone_product, category_id } = location.state || {};
    const subcategory_id = gemstone_product[0]?.sub_id
    const Get_user_is_active = localStorage.getItem("user_is_active")
    const [is_loading, set_set_Is_Loading] = useState(false)
    const [products, setProducts] = useState([])
    const [currentPage, setCurrentPage] = useState(1);
    const productsPerPage = 12; // Show 12 products per page

    // Calculate total pages safely
    const totalPages = Math.ceil(products?.product?.length / productsPerPage) || 1;

    // Calculate the products to display on the current page
    const startIndex = (currentPage - 1) * productsPerPage;
    const currentProduct = products?.product?.slice(startIndex, startIndex + productsPerPage) || [];

    // Pagination controls
    const handlePageChange = (page) => {
        setCurrentPage(page);
    };

    const handleNext = () => {
        if (currentPage < totalPages) {
            setCurrentPage(currentPage + 1);
        }
    };

    const handlePrev = () => {
        if (currentPage > 1) {
            setCurrentPage(currentPage - 1);
        }
    };

    // <--------- Add To Favorite --------->
    const Handle_add_to_favorite = async (id, cat_id, sub_id) => {
        set_set_Is_Loading(true)
        const data = {
            cat_id: cat_id,
            subcat_id: sub_id,
            product_id: id
        }
        try {
            const token = User_Authentication();
            if (!token) {
                toast("User not login here")
                set_set_Is_Loading(false);
                throw new Error("User token not found");
            }
            if (!Get_user_is_active) {
                set_set_Is_Loading(false);
                toast("User not login here")
                return
            }
            const response = await Add_To_Fav(data, { Authorization: `Bearer ${token}` })
            console.log("response", response)
            if (response?.data?.status == "200") {
                Handle_Get_Product_List({ Authorization: `Bearer ${token}` })
                set_set_Is_Loading(false)
            }
            else if (response?.response?.data?.status == "500") {
                set_set_Is_Loading(false)
            }
        }
        catch (error) {
            console.log("error", error)
            set_set_Is_Loading(false)
        }
    }

    const Handle_Get_Product_List = async () => {
        set_set_Is_Loading(true);
        try {
            if (Get_user_is_active) {
                const token = User_Authentication();
                if (!token) {
                    set_set_Is_Loading(false);
                    throw new Error("User token not found");
                }
                const response = await Get_Product_List(
                    { category_id, subcategory_id },
                    { Authorization: `Bearer ${token}` }
                );
                setProducts(response?.data?.data);
            } else {
                const response = await Product_List_Data({ category_id, subcategory_id });
                setProducts(response?.data?.data);
            }
        } catch (error) {
            console.error(error);
        } finally {
            set_set_Is_Loading(false);
        }
    };
    // 
    useEffect(() => {
        Handle_Get_Product_List();
    }, [Get_user_is_active, category_id, subcategory_id]);
    return (
        <>
            {/* <--------- Header section's ------> */}
            <Header />
            {/* <-------- ToastContainer ------------> */}
            <ToastContainer style={{ marginTop: "120px" }} />
            {
                is_loading ? (
                    <Loader />
                ) : (
                    <>
                        {/* <----------- Category_Main_Banner section's------> */}
                        <Category_Main_Banner data={gemstone_product} />
                        {
                            currentProduct?.length > 0 ? (
                                <section className="gi-category py-[40px] max-[767px]:py-[0px]">
                                    <div className="flex flex-wrap justify-between items-center mx-auto min-[1400px]:max-w-[1320px] min-[1200px]:max-w-[1140px] min-[992px]:max-w-[960px] min-[768px]:max-w-[720px] min-[576px]:max-w-[540px]">
                                        <div className="flex flex-wrap w-full">
                                            {/* <!-- Sidebar Area Start --> */}
                                            <Product_Filter />
                                            {/* <!-- Sidebar Area End --> */}
                                            <div className="gi-shop-rightside min-[992px]:w-[75%] max-[767px]:pt-[30px] min-[992px]:w-[75%] min-[768px]:w-full w-full px-[12px]">
                                                {/* <!-- Shop Top Start --> */}
                                                <div className="gi-pro-list-top md:flex items-center justify-between text-[14px] mb-[15px]">
                                                    <div className="min-[768px]:w-[50%] w-full gi-grid-list">
                                                        <h2 className="text-[#4b5966] block text-[22px] max-[767px]:text-[18px] leading-[33px] font-semibold mb-[10px] mx-auto leading-[0] capitalize">List of All {gemstone_product?.title}</h2>
                                                    </div>
                                                    <div className="min-[768px]:w-[50%] w-full gi-sort-select flex justify-end items-center">
                                                        <div className="gi-select-inner relative flex h-[50px] leading-[1.5] bg-[#fff] overflow-hidden">
                                                            <select name="gi-select" id="gi-select" className=" outline-[0] bg-[#fff] grow-[1] text-[#777] cursor-pointer">
                                                                <option selected="" disabled="">Sort by</option>
                                                                <option value="1">Position</option>
                                                                <option value="2">Relevance</option>
                                                                <option value="3">Name, A to Z</option>
                                                                <option value="4">Name, Z to A</option>
                                                                <option value="5">Price, low to high</option>
                                                                <option value="6">Price, high to low</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                {/* <!-- Shop Top End --> */}

                                                {/* <!-- Shop content Start --> */}
                                                <div className="shop-pro-content">
                                                    <div className="shop-pro-inner mx-[-12px]">
                                                        <div className="flex flex-wrap w-full">
                                                            {
                                                                currentProduct?.map((product_list_result) => {
                                                                    const isOutOfStock = product_list_result?.current_stock <= 0; // Check stock status
                                                                    return (
                                                                        <div className={`min-[992px]:w-[33.33%] min-[768px]:w-[50%] min-[576px]:w-[50%] max-[420px]:w-full px-[12px] gi-product-box max-[575px]:w-[50%] max-[575px]:mx-auto pro-gl-content mb-6 ${isOutOfStock ? "opacity-50 pointer-events-none" : ""}`}>
                                                                            <div className="gi-product-content h-full">
                                                                                <div className="gi-product-inner transition-all duration-[0.3s] ease-in-out cursor-pointer overflow-hidden rounded-[5px] shadow-xl pt-4">
                                                                                    <div className="gi-pro-image-outer transition-all duration-[0.3s] delay-[0s] ease z-[11] relative">
                                                                                        <div className="gi-pro-image overflow-hidden">
                                                                                            {
                                                                                                product_list_result?.is_favourite === true ? (
                                                                                                    <span className="flags flex flex-col p-[0] uppercase absolute top-[10px] right-[10px] z-[2]">
                                                                                                        <img className="main-image w-[100%] h-[25px] transition-all duration-[0.3s] ease delay-[0s]"
                                                                                                            src={Common_Images_Transport?.wish_list} alt="Product"
                                                                                                            onClick={() => Handle_add_to_favorite(product_list_result?.id, product_list_result?.cat_id, product_list_result?.sub_id)} />
                                                                                                        {/* <i onClick={() => Handle_add_to_favorite(product_list_result?.id, product_list_result?.cat_id, product_list_result?.sub_id)}
                                                                                                            className="fi-rr-heart transition-all text-[22px]  duration-[0.3s] text-red-500 ease-in-out text-[#777] leading-[10px]"></i> */}
                                                                                                    </span>
                                                                                                ) : (
                                                                                                    <span className="flags flex flex-col p-[0] uppercase absolute top-[10px] right-[10px] z-[2]">
                                                                                                        <i onClick={() => Handle_add_to_favorite(product_list_result?.id, product_list_result?.cat_id, product_list_result?.sub_id)}
                                                                                                            className="fi-rr-heart transition-all text-[22px] duration-[0.3s]  ease-in-out text-[#777] leading-[10px]"></i>
                                                                                                    </span>
                                                                                                )
                                                                                            }
                                                                                            <a href="#" className="image productimg7 relative block overflow-hidden pointer-events-none">
                                                                                                <img className="main-image w-[100%] h-[200px] transition-all duration-[0.3s] ease delay-[0s]"
                                                                                                    src={`${IMG_BASE_URL}${product_list_result?.single_image?.image_url}`} alt="Product" />
                                                                                            </a>
                                                                                            {isOutOfStock && (
                                                                                                <div className="absolute top-2 right-2 bg-red-600 text-white text-sm px-2 py-1 rounded">
                                                                                                    Out of Stock
                                                                                                </div>
                                                                                            )}
                                                                                        </div>
                                                                                    </div>
                                                                                    <div className="gi-pro-content h-full p-[30px] pt-[0] relative z-[10] flex flex-col text-center">
                                                                                        <h5 className="gi-pro-stitle font-normal text-[#0F1726] text-[16px] font-semibold leading-[1.2] capitalize">
                                                                                            {product_list_result?.name}
                                                                                        </h5>
                                                                                        <div className="gi-pro-rat-price mt-[5px] mb-[0] flex flex-col">
                                                                                            <span className="gi-price">
                                                                                                <span className="new-price text-[#000] text-[14px]">
                                                                                                    <span className="ml-3 font-bold text-[#4C5159]">SKU :</span>
                                                                                                    {product_list_result?.sku}
                                                                                                </span>
                                                                                            </span>
                                                                                        </div>
                                                                                        <div className="flex flex-col mt-2 justify-center gap-4 items-center">
                                                                                            <span className="new-price text-[#000] font-medium text-[16px]">
                                                                                                Rs.{product_list_result?.purchase_price}
                                                                                            </span>
                                                                                            <button onClick={() => {
                                                                                                if (!isOutOfStock) { navigate("/product_details", { state: { product_list_result, category_id: category_id, subcategory_id: subcategory_id } }); }
                                                                                            }}
                                                                                                type="button"
                                                                                                className={`text-gray-900 hover:text-white border border-gray-800 hover:bg-gray-900 focus:ring-4 
                                                                                                 focus:outline-none focus:ring-gray-300 font-medium rounded-full text-sm px-5 py-2.5 text-center dark:border-gray-600
                                                                                                 dark:text-gray-400 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-800 ${isOutOfStock ? "cursor-not-allowed" : ""
                                                                                                    }`} disabled={isOutOfStock}>
                                                                                                {isOutOfStock ? "Not Available" : "View More"}
                                                                                            </button>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    );
                                                                })
                                                            }

                                                        </div>
                                                    </div>
                                                    {/* <!-- Pagination Start --> */}
                                                    <div className="gi-pro-pagination pt-[15px] pb-[15px] flex justify-between items-center border-t-[1px] border-solid border-[#eee] max-[575px]:flex-col">
                                                        <span className="text-[14px] text-[#777] max-[575px]:mb-[10px]">Showing {startIndex + 1}-{Math.min(startIndex + productsPerPage, products?.product?.length)} of {products?.product?.length} item(s)</span>
                                                        <ul className="gi-pro-pagination-inner flex">
                                                            <li>
                                                                <button onClick={handlePrev} className="next w-auto px-[13px] text-[#fff] m-1 p-2 bg-[#5caf90] leading-[30px] h-[32px] bg-red-500 flex text-center align-top text-[16px] justify-center items-center rounded-[5px]">
                                                                    Prev
                                                                </button>
                                                            </li>

                                                            {[...Array(totalPages).keys()].map((page) => (
                                                                <li key={page} className="inline-block float-left mr-[5px]">
                                                                    <button
                                                                        onClick={() => handlePageChange(page + 1)}
                                                                        className={`transition-all duration-[0.3s] m-1 p-2 ease-in-out w-[32px] h-[32px] font-light 
                                                                        text-[#777] leading-[32px] bg-[#eee] flex text-center align-top 
                                                                        text-[16px] justify-center items-center rounded-[5px]
                                                                         ${currentPage === page + 1 ? 'active bg-red-500 text-white' : 'bg-gray-300 text-white'}`}
                                                                    >
                                                                        {page + 1}
                                                                    </button>
                                                                </li>
                                                            ))}

                                                            <li>
                                                                <button onClick={handleNext} className="next w-auto px-[13px] text-[#fff] m-1 p-2 bg-[#5caf90] leading-[30px] h-[32px] bg-red-500 flex text-center align-top text-[16px] justify-center items-center rounded-[5px]">
                                                                    Next
                                                                </button>
                                                            </li>
                                                        </ul>
                                                    </div>

                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </section>
                            ) : (
                                <div className="gi-product-content h-full">
                                    <div className="gi-product-inner transition-all duration-[0.3s] ease-in-out cursor-pointer overflow-hidden rounded-[5px] shadow-xl pt-4">
                                        <div className="gi-pro-image-outer transition-all duration-[0.3s] delay-[0s] ease z-[11] relative">
                                            <div className="gi-pro-image overflow-hidden m-[10]">
                                                <h1>Product not available at the moment. Please check back later</h1>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )
                        }

                        {/*  */}
                        <Footer />
                    </>
                )
            }
        </>
    )
}

export default Home_View_All_Product