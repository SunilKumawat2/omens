import React, { useEffect, useState } from 'react'
import Header from '../../../common/header/Header'
import User_Dashbaord_Common_Section from '../user_dashboard_common_section/User_Dashbaord_Common_Section'
import { Get_User_Booked_Pooja_List } from '../../../../api/pooja/Pooja';
import { User_Authentication } from '../../../../user_authentication/User_Authentication';
import Loader from '../../../../loader/Loader';
import { IMG_BASE_URL } from '../../../../config/Config';

const User_Dashboard_My_Pooja_List = () => {
    const [isLoading, setIsLoading] = useState([]);
    const [get_booked_pooja_list, set_User_Booked_Pooja_List] = useState([]);

    useEffect(() => {
        const handle_get_user_booked_pooja_list = async () => {
            setIsLoading(true)
            try {
                const token = User_Authentication();
                if (!token) {
                    setIsLoading(false);
                    throw new Error("User token not found");
                }
                const response = await Get_User_Booked_Pooja_List({ Authorization: `Bearer ${token}` })
                if (response?.data?.status == "200") {
                    set_User_Booked_Pooja_List(response?.data?.data)
                    setIsLoading(false)
                }
                else if (response?.response?.data?.status == "500") {
                    setIsLoading(false)
                }
            }
            catch (error) {
                setIsLoading(false)
            }
        }
        handle_get_user_booked_pooja_list();
    }, [])

    const formatTime = (time) => {
        const [hours, minutes] = time.split(":");
        const intHours = parseInt(hours, 10);
        const ampm = intHours >= 12 ? "pm" : "am";
        const formattedHours = intHours % 12 || 12;
        return `${formattedHours}:${minutes} ${ampm}`;
    };

    return (
        <div>
            {/* <----------- Header section's ------------> */}
            <Header />
            {
                isLoading ? (
                    <Loader />
                ) : (
                    <section className="gi-faq py-[40px] max-[767px]:py-[30px] gi-wishlist">
                        <div className="flex flex-wrap justify-between items-center mx-auto min-[1400px]:max-w-[1320px] min-[1200px]:max-w-[1140px] min-[992px]:max-w-[960px] min-[768px]:max-w-[720px] min-[576px]:max-w-[540px]">
                            <div className="container-x mx-auto">
                                <div className="w-full my-10">
                                    <div className="w-full bg-white shadow-xl p-5">
                                        <div className="my_account w-full flex space-x-10">
                                            <User_Dashbaord_Common_Section />
                                            {
                                                get_booked_pooja_list?.pooja_list?.length > 0 ? (
                                                    <div className="flex-1">
                                                        <div className=" w-full">
                                                            <h1 className="font-bold text-[24px] text-qblack mb-4">Book List
                                                            </h1>
                                                            <div
                                                                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-3 md:gap-6">
                                                                {
                                                                    get_booked_pooja_list?.pooja_list?.map((get_booked_pooja_list_result) => {
                                                                        return (
                                                                            <div className="border rounded-lg p-4 bg-white">
                                                                                <div className="flex justify-between items-center">
                                                                                    <div className="flex gap-3 items-center">
                                                                                        <img src={`${IMG_BASE_URL}${get_booked_pooja_list_result?.image}`} className="rounded-md h-16 w-16"
                                                                                            alt="" />
                                                                                        <div>
                                                                                            <h5 className="text-lg font-medium text-black line-clamp-1">{get_booked_pooja_list_result?.title}</h5>
                                                                                            <p class="text-gray-500 text-sm clamped-text">{get_booked_pooja_list_result?.short_description}</p>
                                                                                        </div>
                                                                                    </div>

                                                                                </div>

                                                                                <div className="shadow rounded-md p-4 mt-3">
                                                                                    <div className="grid grid-cols-2 gap-4">

                                                                                        <div>
                                                                                            <span className="text-sm text-gray-400">Astrologer Name</span>
                                                                                            <h5 className="text-[14px] text-[#0F1726] font-medium">{get_booked_pooja_list_result?.astro?.name}</h5>
                                                                                        </div>
                                                                                        <div>
                                                                                            <span className="text-sm text-gray-400">Booking Date</span>
                                                                                            <h5 className="text-[14px] text-[#0F1726] font-medium">{get_booked_pooja_list_result?.pooja_date}</h5>
                                                                                        </div>

                                                                                        <div>
                                                                                            <span className="text-sm text-gray-400">Pooja Timing</span>
                                                                                            <h5 className="text-[14px] text-[#0F1726] font-medium"> {formatTime(get_booked_pooja_list_result?.from_time)} to {formatTime(get_booked_pooja_list_result?.to_time)}</h5>
                                                                                        </div>

                                                                                        <div>
                                                                                            <span className="text-sm text-gray-400">Amount</span>
                                                                                            <h5 className="text-[14px] text-red-700 font-medium">Rs.{get_booked_pooja_list_result?.price}/-</h5>
                                                                                        </div>
                                                                                        <div>
                                                                                            <span className="text-sm text-gray-400">Category</span>
                                                                                            <h5 className="text-[14px] text-red-700 font-medium">{get_booked_pooja_list_result?.category?.title}</h5>
                                                                                        </div>
                                                                                        <div>
                                                                                            <span className="text-sm text-gray-400">Status</span>
                                                                                            {
                                                                                                get_booked_pooja_list_result?.status == "1" ? (
                                                                                                    <h5 className="text-[14px] text-yellow-500 font-medium">Pending</h5>
                                                                                                ) : get_booked_pooja_list_result?.status == "2" ? (
                                                                                                    <h5 className="text-[14px] text-gray-500 font-medium">Processing</h5>
                                                                                                ) : get_booked_pooja_list_result?.status == "3" ? (
                                                                                                    <h5 className="text-[14px] text-green-700 font-medium">Complete</h5>
                                                                                                ) : (
                                                                                                    <h5 className="text-[14px] text-gray-700 font-medium">Unknown Status</h5>
                                                                                                )
                                                                                            }
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        )
                                                                    })
                                                                }
                                                            </div>
                                                        </div>
                                                    </div>
                                                ) : (
                                                    <div className='m-auto text-center'>
                                                        <h4>No bookings Pooja available at the moment</h4>
                                                    </div>
                                                )
                                            }

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                )
            }
        </div>
    )
}

export default User_Dashboard_My_Pooja_List